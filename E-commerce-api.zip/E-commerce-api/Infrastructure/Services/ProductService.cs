﻿using Core.Interfaces;
using Core.Models.Product;
using Core.Models.User;
using Domain;
using Infrastructure.Database;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using NETCore.MailKit.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Services
{
    public class ProductService : IProductService
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _env;

        public ProductService(AppDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        public async Task<ProductMasterDto> addProduct(ProductMasterDto dto)
        {
            var existingProduct = _context.ProductMaster.Where(p => p.ProductCode  == dto.ProductCode).FirstOrDefault();
            if (existingProduct != null)
            {
                return null;
            }

            string profileImagePath = ImagePath(dto.ProductImage);

            var product = new ProductMaster
            {
                ProductCode = dto.ProductCode,
                Name = dto.Name,
                Category = dto.Category,
                Brand = dto.Brand,
                ProductImage = profileImagePath,
                SellingPrice = dto.SellingPrice,
                PurchasePrice = dto.PurchasePrice,
                PurchaseDate = dto.PurchaseDate,
                Stock = dto.Stock,
                isDeleted = false
            };

            await _context.ProductMaster.AddAsync(product);
            await _context.SaveChangesAsync();
        
            return await Task.FromResult(dto);

        }

        public async Task<IEnumerable<ProductMaster>> GetProducts()
        {
            var products = await _context.ProductMaster.ToArrayAsync();
            return products;
        }

        public async Task<string> UpdateProduct(updateProductDto dto)
        {
            var existingProduct = _context.ProductMaster.Where(p => p.ProductCode == dto.ProductCode).FirstOrDefault();
            string profileImagePath = ImagePath(dto.ProductImage);
            if (existingProduct != null) 
            {
                if(profileImagePath != "")
                {
                existingProduct.ProductImage = profileImagePath;
                }
                existingProduct.Name = dto.Name;
                existingProduct.Category = dto.Category;
                existingProduct.Brand = dto.Brand;
                existingProduct.SellingPrice = dto.SellingPrice;
                existingProduct.PurchasePrice = dto.PurchasePrice;
                existingProduct.PurchaseDate = dto.PurchaseDate;
                existingProduct.Stock = dto.Stock;
                existingProduct.isDeleted = false;
                await _context.SaveChangesAsync();
                return "successful";
            }
            return "unsuccessful";
        }

        public async Task<bool> RemoveProduct(string ProductCode)
        {
            var existingProduct = await _context.ProductMaster.Where(p => p.ProductCode == ProductCode).FirstOrDefaultAsync();
            if (existingProduct != null)
            {
                existingProduct.isDeleted = true;
                await _context.SaveChangesAsync();
                return true;
            }
            return false;
        }

        public string ImagePath(IFormFile image)
        {
            if (image != null)
            {

                var folderPath = Path.Combine(_env.WebRootPath, "product_images");

                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                
                var fileName = $"{Guid.NewGuid()}{Path.GetExtension(image.FileName)}";
                var filePath = Path.Combine(folderPath, fileName);
                                
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    image.CopyTo(stream); 
                }

                return $"/product_images/{fileName}";

            }
            return "/profile_images/default.jpg";
        }
    }
}
