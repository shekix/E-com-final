﻿using Core.Interfaces;
using Core.Models.Sales;
using Dapper;
using Domain;
using Infrastructure.Database;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Services
{
    public class PaymentService : IPaymentService
    {
        private readonly AppDbContext _context;
        private readonly IConfiguration _configuration;
        private readonly SqlConnection _connection;
        public PaymentService(AppDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
            _connection = new SqlConnection(configuration.GetConnectionString("DefaultConnection"));
        }

        public async Task<IEnumerable<dynamic>> getCardDetail()
        {
            var query = "SELECT * FROM CardDetails";
            var result = await _connection.QueryAsync(query);
            return result;
        }

        public async Task<string> CreateInvoice(SalesMasterDto dto)
        {
            var exitingUser = await _context.Users.Where(u=>u.Id == dto.UserId).FirstOrDefaultAsync();
            var newInvoiceId = CreateInvoiceId();
            var Invoice = new SalesMaster
            {
                UserId = dto.UserId,
                InvoiceId = newInvoiceId ,
                InvoiceDate = DateTime.Now,
                SubTotal = dto.SubTotal,
                Address = exitingUser.AddressLine1 +" "+exitingUser.AddressLine2,
                Zipcode = exitingUser.zipcode,
                CountryId = exitingUser.CountryId,
                StateID = exitingUser.StateId,  
            };
            await _context.SalesMaster.AddAsync(Invoice);
            await _context.SaveChangesAsync();
            var result = await CreateSalesDetail(newInvoiceId,dto.CartId);
            return result;
        }


        public string CreateInvoiceId()
        {
            var lastInvoiceId = _context.SalesMaster.OrderByDescending(s=>s.InvoiceId).FirstOrDefault();
            if (lastInvoiceId == null)
            {
                return "ORD001";
            }
            int numericPart = int.Parse(lastInvoiceId.InvoiceId.Substring(3));
            // Increment and format with leading zeros
            var newInvoiceId = $"ORD{(numericPart + 1).ToString("D3")}";

            return newInvoiceId;
        }

        public async Task<string> CreateSalesDetail(string InvoiceId,int CartId)
        {
           var Products = await _context.CartDetails.Where(c=>c.CartId == CartId).ToListAsync();
            foreach (var Product in Products)
            {
                var ProductDetail = await _context.ProductMaster.Where(P=>P.Id == Product.productId).FirstOrDefaultAsync();
                var saleDetail = new SalesDetail
                {
                    InvoiceId = InvoiceId,
                    ProductID = ProductDetail.Id,
                    ProductCode = ProductDetail.ProductCode,
                    SaleQunatity = Product.quantity,
                    SellingPrice = ProductDetail.SellingPrice,
                };
                await _context.SalesDetail.AddAsync(saleDetail);
                ProductDetail.Stock -= Product.quantity;
                await _context.SaveChangesAsync();
            }

            _context.CartDetails.RemoveRange(Products);
            await _context.SaveChangesAsync();
            return "success";
        }



        public async Task<ReceiptDto> generateReceipt(int userId)
        {
            var latestInvoiceId = await _context.SalesMaster.OrderByDescending(s => s.InvoiceId).Where(s=>s.UserId == userId).FirstOrDefaultAsync();

            var country = await _context.Countries.Where(c=>c.Id == latestInvoiceId.CountryId).FirstOrDefaultAsync();

            var state = await _context.States.Where(s=>s.Id == latestInvoiceId.StateID).FirstOrDefaultAsync();

            var salesDetail = await _context.SalesDetail.Where(s => s.InvoiceId == latestInvoiceId.InvoiceId).ToListAsync();
            
            List<ProductList> products = new List<ProductList>();
            foreach (var product in salesDetail)
            {

                var productInfo = await _context.ProductMaster.Where(p=>p.Id == product.ProductID).FirstOrDefaultAsync();

                products.Add(new ProductList {
                    ProductName = productInfo.Name,
                    Quantity = product.SaleQunatity,
                    SellingPrice= product.SellingPrice,
                });

            }

            var receipt = new ReceiptDto
            {
                InvoiceId = latestInvoiceId.InvoiceId,
                OrderDate = latestInvoiceId.InvoiceDate,
                Address = latestInvoiceId.Address,
                Zipcode = latestInvoiceId.Zipcode,
                Country = country.Name,
                State = state.Name,
                products = products,
                Subtotal = latestInvoiceId.SubTotal
            };

            return receipt;
        }


    }
}
