﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Models.Sales
{
    public class ReceiptDto
    {
        public string InvoiceId { get; set; }
        public DateTime OrderDate { get; set; }
        public string Address { get; set; }
        public string Zipcode { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public List<ProductList> products { get; set; }
        public float Subtotal { get; set; }


    }





}
