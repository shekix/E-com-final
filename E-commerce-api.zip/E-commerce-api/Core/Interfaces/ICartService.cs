﻿using Core.Models.Cart;
using Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Interfaces
{
    public interface ICartService
    {
        Task<CartDetails> addToCart(CartDetailDto dto);

        Task<IEnumerable<getCartDataResponse>> getCartDetails(int Id);
        Task<string> removeFromCart(int productId, int CartId);
        Task<string> decrementQuantity(decrementQuantityDto dto);
    }
}
