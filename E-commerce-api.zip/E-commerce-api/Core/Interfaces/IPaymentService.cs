﻿using Core.Models.Sales;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Interfaces
{
    public interface IPaymentService
    {
        Task<IEnumerable<dynamic>> getCardDetail();
        Task<string> CreateInvoice(SalesMasterDto dto);
        Task<ReceiptDto> generateReceipt(int userId);
    }
}
