﻿using Core.Models.Product;
using Core.Models.User;
using Infrastructure.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Globalization;

namespace E_commerce_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
       private readonly ProductService _productService;

        public ProductsController(ProductService productService)
        {
            _productService = productService;
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("Add")]
        public async Task<IActionResult> addProuct(ProductMasterDto dto)
        {
            var result = await _productService.addProduct(dto);
            if (result != null)
            {
                return Ok(result);
            }
            return Conflict("product with this code already exists");
        }

        [HttpGet("All")]
        public async Task<IActionResult> getAll()
        {
            var result = await _productService.GetProducts();
            return Ok(result);
        }

        [Authorize(Roles = "Admin")]
        [HttpPut("Update")]
        public async Task<IActionResult> updateProduct(updateProductDto dto)
        {
            var result = await _productService.UpdateProduct(dto);
            if (result == "successful")
            {
                return Ok(result);
            }
            return NotFound(result);
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("Remove")]
        public async Task<IActionResult> RemoveProduct(string ProductCode)
        {
            var result = await _productService.RemoveProduct(ProductCode);
            if (result == true)
            {
                return Ok(result);
            }
            return NotFound(result);
        }
    }
}
