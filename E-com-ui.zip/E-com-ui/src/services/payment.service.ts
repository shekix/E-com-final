import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  http = inject(HttpClient)

  private paymentUrl = 'https://localhost:7051/api/Payment';

  public getCardData():Observable<any>{
    return this.http.get<any>(`${this.paymentUrl}/cardDetail`);
  }

  public createInvoice(data:any):Observable<any>{
    return this.http.post<any>(`${this.paymentUrl}/createInvoice`,data,{responseType :'text' as 'json'});
  }


  public getReceipt(userId:any):Observable<any>{
    return this.http.get<any>(`${this.paymentUrl}/receipt?userId=${userId}`);
  }
}
