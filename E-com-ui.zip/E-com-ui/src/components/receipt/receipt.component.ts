import { Component, OnInit } from '@angular/core';
import { PaymentService } from '../../services/payment.service';
import { CurrencyPipe, DatePipe, NgFor } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-receipt',
  standalone: true,
  imports: [DatePipe,NgFor,CurrencyPipe],
  templateUrl: './receipt.component.html',
  styleUrl: './receipt.component.css'
})
export class ReceiptComponent implements OnInit {

  receipt :any;
  userId = sessionStorage.getItem('id');
  constructor(private paymentService:PaymentService,private route:Router){}

  ngOnInit(): void {
    this.paymentService.getReceipt(this.userId).subscribe({
      next:(result:any)=>{
        this.receipt = result;
        console.log(this.receipt);
        
      },
      error:(error:any)=>{
        alert('an error occured');
      }
    })
  }

  shop(){
    this.route.navigateByUrl('home/productListing')
  }

}
